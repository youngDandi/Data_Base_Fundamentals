use Planalto;

Drop table if exists tTrabalhos;
  truncate table tCalendario;

Drop procedure if exists pPreencherCalendario;

DELIMITER --
CREATE PROCEDURE pPreencherCalendario(in dataInicial Date , in dataFinal Date)
BEGIN
    DECLARE dataa DATE;
    declare indicador varchar(2);
    
    SET dataa = dataInicial;
    while dataa < dataFinal do
		set indicador='';
         if( DAYOFWEEK(dataa)=1)  then set indicador="D";
        elseif (pRetorneFeriado(dataa)=true)  then set indicador="F"; 
        elseif((DAYOFWEEK(dataa)=2) and pRetorneFeriado( ADDDATE(dataa,INTERVAL 1 DAY))=true)   then set indicador="F"; 
         elseif((DAYOFWEEK(dataa)=6) and pRetorneFeriado( SubDATE(dataa,INTERVAL 1 DAY))=true)   then set indicador="F"; 
         
        end if;
        INSERT INTO tCalendario VALUES (
		YEAR(dataa)*10000+MONTH(dataa)*100 + DAY(dataa),dataa,week(dataa),YEAR(dataa),indicador);
        SET dataa = ADDDATE(dataa,INTERVAL 1 DAY);
    END WHILE;
END
--   

delimiter --
create procedure pInsertTurnos(inicio Time,fim Time , custoHora double )
begin
insert into tTurnos(inicioTurno, fimTurno, custoPorHora )
values(inicio, fim, custoHora );
end
--

delimiter --
create procedure pInsertBancos(banco varchar(20) )
begin
insert into tBancos(banco )
values(banco );
end
--
delimiter --
create procedure pInsertCentros(nomeCentro varchar (20))
begin
insert into tCentros(nomeCentro )
values(nomeCentro);
end
--

delimiter --
create procedure pInsertAreas(nomeArea varchar (30),fkcodcentro int)
begin
insert into tAreas(nomeArea ,fkcodcentro )
values(nomeArea,fkcodcentro);
end
--

delimiter --
create procedure pInsertObreiros(nome varchar (25), apleido varchar (25),dataNascimento date ,
numeroConta varchar(15), fkcodbanco int ,fkcodarea int )
begin
insert into tObreiros(nome, apleido,dataNascimento ,numeroConta,fkcodbanco ,fkcodarea)
values(nome, apleido,dataNascimento ,numeroConta,fkcodbanco ,fkcodarea );
end
--



delimiter --
create procedure pInsertPagamentos( )
begin
insert into tPagamentos( )
values( );
end
--


drop procedure if exists pInserttrabalhos;
delimiter --

create procedure pInsertTrabalhos(fkcodobreiro int, fkcoddata integer,fkcodturno int,horaEntrada Time,horaSaida Time)
begin  
declare auxSemana int; 
declare inicioSemana date;
declare fimSemana date;
declare quantia double;
 declare auxInicioTurno time;
declare auxFimTurno time;
declare custo double;
declare quantiaExtra double;
declare horasExtras int;
declare minutosAtraso int;
declare minutosAcumulados int;
declare indicadoraux varchar(2);
 declare auxQuantia double; 
 declare aniversario date; 
 declare data1 date; 
    select  inicioTurno into auxInicioTurno   from tTurnos where  fkcodturno=codturno;
	select    fimTurno into auxFimTurno from tTurnos where fkcodturno=codturno;
	select  custoPorHora into custo from tTurnos where fkcodturno=codturno;
	 
     select   dataa into data1  from tCalendario where fkcoddata=coddata;
     
	select   indicador into indicadoraux  from tCalendario where fkcoddata=coddata;
	select   semana into auxSemana  from tCalendario where fkcoddata=coddata;
    select    min(dataa) into inicioSemana from tCalendario where auxSemana=semana and ano=year(curdate()) group by semana;
	select    max(dataa) into fimSemana from tCalendario where auxSemana=semana and ano=year(curdate()) group by semana;
	
    
	select   dataNascimento into aniversario  from tObreiros where fkcodobreiro=codobreiro;
    
    
    if((month(aniversario)=month(data1)) and (day(aniversario)=day(data1))) then 
		set quantia=8*custo; set horaEntrada=auxInicioTurno; 
    else    
	if(horaEntrada is not null and horaSaida is not null) then
		if(horaEntrada<auxInicioTurno)then set  horaEntrada=auxInicioTurno;
		end if;
	if((horaEntrada=auxInicioTurno or horaEntrada>auxInicioTurno) and horaEntrada<auxFimTurno )then
    set quantia=(hour(auxFimTurno)-hour(horaEntrada))*custo;
       	if(horaSaida=auxFimTurno or horaSaida<auxFimTurno)then set quantia= (hour(horaSaida)-hour(horaEntrada))*custo;

			if(indicadoraux='F' or indicadoraux='D')then set quantia=quantia+(quantia*0.5); 

			end if;
        elseif( (horaSaida>auxFimTurno) and (indicadoraux!='F' and indicadoraux!='D') ) then set horasExtras=hour(horaSaida)-hour(auxFimTurno);
			set minutosAcumulados=horasExtras*60; 
			if(horasExtras<=3) then set quantiaExtra=custo*0.1*horasExtras;
			elseif(horasExtras<=5) then set quantiaExtra=custo*0.3+(custo*0.15*(horasExtras-3));
			elseif(horasExtras<=7)then set quantiaExtra=custo*0.6+(custo*0.20*(horasExtras-5));
			else  set quantiaExtra=custo;
			end if;  
	    set quantia=quantiaExtra+((hour(auxFimTurno)-hour(auxInicioTurno))*custo);
        end if;
        if(horaEntrada>auxInicioTurno) then 
        set  minutosAtraso=minute(timediff(horaEntrada,auxInicioTurno))+(hour(timediff(horaEntrada,auxInicioTurno))*60);
        set quantia=(quantia)-(custo*minutosAtraso*0.05);
        end if;
    else  set horaEntrada=Null;   set horaSaida=Null;
	end if;
	end if;
	end if;
insert into tTrabalhos(fkcodobreiro, fkcoddata,fkcodturno,horaEntrada ,horaSaida ,quantiaDiaria ,semana ,inicioSemana,
fimSemana,minutosAtraso,minutosAcumulados)
values(fkcodobreiro, fkcoddata,fkcodturno,horaEntrada ,horaSaida ,quantia,auxSemana,inicioSemana,
fimSemana,minutosAtraso,minutosAcumulados); 
end
--

 
     
       SELECT 
    *
FROM
    tTrabalhos;
SELECT 
    *
FROM
    tObreiros;