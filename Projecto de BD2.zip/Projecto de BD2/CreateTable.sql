create database Planalto;
use Planalto;

create table tTurnos (
codturno int AUTO_INCREMENT primary key, 
inicioTurno Time not null unique , 
fimTurno Time not null unique ,
 custoPorHora double not null
 );

create table tBancos (
 codbanco int primary key AUTO_INCREMENT, 
banco varchar(20) not null  UNIQUE
);

create table tSemanas( 
semana int not null,
inicioSemana Date primary key, 
fimSemana Date not null unique
);

Create table tCentros ( 
codcentro int primary key AUTO_INCREMENT, 
nomeCentro varchar (20) not null unique
);

 CREATE TABLE tCalendario (
 coddata integer primary key,
 dataa DATE NOT NULL unique,
 semana INTEGER NOT NULL,
 ano INTEGER NOT NULL,
 indicador  varchar(2) default('')
) ;
 

create table tAreas (
codArea int primary key AUTO_INCREMENT,
nomeArea varchar (30) not null unique,
fkcodcentro int,
foreign key (fkcodcentro) REFERENCES tCentros (codcentro)
); 

create table tObreiros ( 
codobreiro int primary key AUTO_INCREMENT,
 nome varchar (25)not null , 
apleido varchar (25)not null ,
 dataNascimento date not null,
numeroConta varchar(15) not null unique, 
quantia double,
 fkcodbanco int ,
 fkcodarea int, 
FOREIGN key (fkcodbanco )REFERENCES tBancos (codbanco),
FOREIGN key (fkcodarea )REFERENCES tAreas (codarea)                     
);

create table tPagamento (
quantia double,
semana int not null,
inicioSemana date,
fimSemana date not null,
fkcodObreiro int ,
FOREIGN key (fkcodobreiro )REFERENCES tObreiros (codobreiro),
FOREIGN key (inicioSemana )REFERENCES tSemana (inicioSemana),
primary key (fkcodobreiro, inicioSemana)                         
);


create table tTrabalhos ( 
fkcodobreiro int,    
 fkcoddata integer, 
 fkcodturno int,
 minutosAtraso int,
 minutosAcumulados int,
horaEntrada Time,
horaSaida Time,
quantiaDiaria double,
semana int not null,
inicioSemana date not null,
fimSemana date not null,
foreign key (fkcodturno) references tTurnos(codturno),
foreign key (fkcodobreiro) references tObreiros(codobreiro),
foreign key (fkcoddata) references tCalendario(coddata),
primary key (fkcodobreiro,fkcoddata)
);


