use Planalto;

 Delimiter --
create trigger noInsertTurnos before insert on tTurnos
for each row
begin
signal sqlstate "45000" set message_text=" Bloqueada a Insercao de Turnos";
end
--