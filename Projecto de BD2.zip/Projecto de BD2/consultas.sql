delimiter --
create procedure pAniversariosDaSemana()
begin
select codobreiro, nome, apleido,day(dataNascimento),tAreas.nomeArea from tObreiros,tAreas
where (week(curdate())=week(concat(year(curdate()),"-",month(dataNascimento),"-",day(dataNascimento)))) 
and (fkcodarea=codarea)
order by fkcodarea  ,  day(dataNascimento) ;
end
--

delimiter --
create procedure pDomingosEFeriadosNoAno()
begin
select ano, dataa, indicador from tCalendario
where indicador!='' and ano=year(curdate());
end
--

delimiter --
create procedure pAbonosABancos()
begin
select tBancos.banco,numeroConta, nome, apleido,quantia from tObreiros,tBancos
where fkcodbanco=codbanco
order by tBancos.banco  , numeroConta ;
end
--
create table tS( 
sem int,
ano int,  
fimSemana Date not null unique   ,
primary key(sem,ano)
);

 insert into tS   (select mes,ano, min(dataa),adddate(dataa,INTERVAL 6 day )from tCalendario
 wherere mes=1
group by ano, mes);
select week("2022-01-15");
select *from tS;
select ano,indicador from tCalendario
where ano=2022 and indicador!="";

select sum(ano) from tCalendario
where ano=2022 and semana=1;



    select ano,semana, min(dataa), sum(ano),max(dataa)  from tCalendario
where semana=1 and ano=2022  
group by ano,semana;




