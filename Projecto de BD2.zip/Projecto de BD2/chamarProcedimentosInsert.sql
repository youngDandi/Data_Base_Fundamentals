use Planalto;

             call pPreencherCalendario('2022-01-01','2027-12-31');
             
             call  pInsertTurnos('00:00:00','08:00:00' , 700);
             call  pInsertTurnos('08:00:00','16:00:00' , 300);
             call  pInsertTurnos('17:00:00','00:00:00' , 500);
             call pInsertBancos("BFA" );
             call pInsertBancos("BAI" );
             call pInsertBancos("Atlantico" );
             
             call  pInsertCentros("Leya");
             call  pInsertCentros("RR");
             call  pInsertCentros("LA");
            call  pInsertCentros("PC");
            
             call pInsertAreas("Produção Textual",1);
             call pInsertAreas("Marketing Editorial",1);
             call pInsertAreas("Edição",2);
             call pInsertAreas("Gráfica",3);
			 call pInsertAreas("Revisão",4);
             
             call pInsertObreiros("Ednaro", "Soares","1990-06-13" ,"001",1,5);
             call pInsertObreiros("Vanderleya", "SmtTrabalhostTurnostTrabalhosith","1990-06-13" ,"002",3,4);
             call pInsertObreiros("Joao", "Pinto","1990-06-13" ,"003",4,3);
             call pInsertObreiros("Luis", "Alberto","1992-06-20" ,"004",1,2);
             call pInsertObreiros("Soarito", "Almeida","2022-06-15" ,"005",1,1);
             call pInsertObreiros("Pedro", "Antonio","2002-06-24" ,"006",4,2);
             call pInsertObreiros("Reginaldo", "Simao","2003-06-28" ,"007",1,2);
             call pInsertObreiros("Sonia", "Soares","2003-06-28" ,"008",1,3);
             call pInsertObreiros("Paula", "Eliza","2002-06-30" ,"009",3,1);
             call pInsertObreiros("Ruben", "Manuel","2005-06-29" ,"010",4,3);
             call pInsertObreiros("Celma", "Deolinda","2001-06-27" ,"011",3,4);
             call pInsertObreiros("Celina", "Andrade","200-06-22" ,"012",3,5);
             call pInsertObreiros("Alda", "Antonio","1993-06-23" ,"013",3,5);
             call pInsertObreiros("Rosa", "da Silva","1995-05-03" ,"014",3,4);
             call pInsertObreiros("Elga", "Paulo","2000-06-27" ,"015",1,4);
			call pInsertObreiros("pedro", "pp","2000-07-02" ,"016",1,4);
     
SELECT 
    *
FROM
    tObreiros;


           
 call pInsertTrabalhos(2,20220615 ,1,"00:00:00","8:00:00") ;
  call pInsertTrabalhos(2,20220616 ,1,"00:00:00","10:00:00") ;
  call pInsertTrabalhos(1,20220615 ,2,"08:20:00","16:00:00") ;
  call pInsertTrabalhos(1,20220616 ,1,"13:00:00","14:00:00");
  call pInsertTrabalhos(4,20220618 ,3,"16:00:00","23:00:00");
  call pInsertTrabalhos(5,20220620 ,1,"00:00:00","09:00:00") ;
  call pInsertTrabalhos(1,20220621 ,2,"09:00:00","16:00:00") ;
  call pInsertTrabalhos(2,20220622 ,3,"16:00:00","22:00:00") ;
  call pInsertTrabalhos(4,20220623 ,1,null,null) ;
  call pInsertTrabalhos(4,20220626 ,3,"18:00:00","23:00:00") ;
  call pInsertTrabalhos(15,20220627 ,2,"08:40:00","20:00:00") ;
  call pInsertTrabalhos(12,20220628 ,1,"00:00:00","05:00:00") ;
  call pInsertTrabalhos(10,20220629 ,2,null,null) ;
  call pInsertTrabalhos(1,20220622 ,2,"08:40:00","20:00:00") ;
  call pInsertTrabalhos(2,20220614 ,1,"00:00:00","05:00:00") ;
  
  
SELECT 
    *
FROM
    tTrabalhos;





SELECT 
    *
FROM
    tT;



set @sem=25;

  insert into tPagamentos(
  select  fkcodobreiro,semana, inicioSemana,fimSemana,sum(quantiaDiaria) from tTrabalhos
where semana=24  and year(inicioSemana)=year(curdate())
group by  fkcodobreiro,inicioSemana,fimSemana,fimSemana
);

SELECT 
    *
FROM
    tPagamentos;
 