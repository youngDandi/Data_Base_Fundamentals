use Planalto;

       
             select *from tObreiros;
             select *from tCalendario;
             truncate table tObreiros;
             SELECT 8 AS HORA, TIME_FORMAT(8, '%h - %i - %s') AS HORA_FORMATADA;
             
          
set @h1="00:40:05";
set @h2="16:00:00";

select @h1,@h2,@h1-@h2;