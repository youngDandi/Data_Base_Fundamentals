use Planalto;

 
  Drop function if exists  pRetorneFeriado;   
delimiter --
create function pRetorneFeriado ( dataa date)
returns boolean
DETERMINISTIC
READS SQL DATA
 begin
 if (((month(dataa)=1 or month(dataa)=5 ) and day(dataa)=1) or (month(dataa)=2 and day(dataa)=4) or
        (month(dataa)=3 and (day(dataa)=1 or day(dataa)=8  or day(dataa)=23))  or (month(dataa)=4 and (day(dataa)=4 or day(dataa)=15))or
        (month(dataa)=9 and day(dataa)=17) or (month(dataa)=11 and (day(dataa)=2 or day(dataa)=11)) or
        (month(dataa)=12 and day(dataa)=25)) then
        return true;
        else
        return false;
        end if;
end
--